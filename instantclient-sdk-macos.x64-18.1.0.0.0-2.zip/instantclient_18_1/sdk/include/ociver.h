#ifndef OCIVER_ORACLE
#define OCIVER_ORACLE

#define OCI_MAJOR_VERSION 18             /* Major release version */
#define OCI_MINOR_VERSION 1              /* Minor release version */

#endif
